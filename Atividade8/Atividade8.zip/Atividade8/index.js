const respostas = [];
const totalPessoas = 45;
let contador = 0;

function enviarPesquisa() {
    if (contador >= totalPessoas) {
        alert("A pesquisa acabou!");
        return;
    }

    const idade = parseInt(document.getElementById("idade").value);
    const sexo = document.querySelector('input[name="sexoEsc"]:checked').id === "sexoMasc" ? "Masculino" : "Feminino";
    const opiniao = parseInt(document.getElementById("opiniao").value);

    respostas.push({ idade, sexo, opiniao });
    contador++;

    atualizarEstatisticas();
    
    document.getElementById("indicedepessoas").innerText = `Pessoa ${contador}/${totalPessoas}`;
}

function atualizaOpiniao() {
    const opiniaoValue = parseInt(document.getElementById("opiniao").value);
    let opiniaoText;

    switch (opiniaoValue) {
        case 0:
            opiniaoText = "Péssimo";
            break;
        case 1:
            opiniaoText = "Regular";
            break;
        case 2:
            opiniaoText = "Bom";
            break;
        case 3:
            opiniaoText = "Ótimo";
            break;
        default:
            opiniaoText = "Regular"; //padrao
    }

    document.querySelector('#opiniaoText').innerHTML = opiniaoText;
}


function atualizarEstatisticas() {
    if (respostas.length === 0) return;

    let idadeSoma = 0;
    let idadeMax = 0;
    let idadeMin = Infinity;
    const opinioes = { 0: 0, 1: 0, 2: 0, 3: 0 };

    respostas.forEach(resposta => {
        idadeSoma += resposta.idade;
        idadeMax = Math.max(idadeMax, resposta.idade);
        idadeMin = Math.min(idadeMin, resposta.idade);
        opinioes[resposta.opiniao]++;
    });

    const idadeMedia = idadeSoma / respostas.length;

    document.querySelector('.resultadosUl').innerHTML = `
        <li>Idade da pessoa mais velha: ${idadeMax}</li>
        <li>Idade da pessoa mais nova: ${idadeMin}</li>
        <li>Idade média: ${idadeMedia.toFixed(2)}</li>
        <li id="qtOti">Quantidade de pessoas que responderam ótimo: ${opinioes[3]} (${((opinioes[3] / respostas.length) * 100).toFixed(2)}%)</li>
        <li id="qtBom">Quantidade de pessoas que responderam bom: ${opinioes[2]} (${((opinioes[2] / respostas.length) * 100).toFixed(2)}%)</li>
        <li id="qtReg">Quantidade de pessoas que responderam regular: ${opinioes[1]} (${((opinioes[1] / respostas.length) * 100).toFixed(2)}%)</li>
        <li id="qtPes">Quantidade de pessoas que responderam péssimo: ${opinioes[0]} (${((opinioes[0] / respostas.length) * 100).toFixed(2)}%)</li>
    `;
}
