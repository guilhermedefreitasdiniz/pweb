function jogarPedra(){
    document.getElementById("player-hand").src="images/fist.png";
    //let jogada = 1;
    document.getElementById("voceEscolheu").innerText="Você escolheu... pedra";
    jogarComRobo();
}

function jogarPapel(){
    document.getElementById("player-hand").src="images/hand.png";
    //let jogada = 2;
    document.getElementById("voceEscolheu").innerText="Você escolheu... papel";
    jogarComRobo();
}

function jogarTesoura(){
    document.getElementById("player-hand").src="images/v.png";
    document.getElementById("voceEscolheu").innerText="Você escolheu... tesoura";
    //let jogada = 3;
    jogarComRobo();
}

function jogarComRobo(){
    let aleatorio = parseInt(Math.random() * 3) + 1;
    if(aleatorio == 1){
        document.getElementById("robot-hand").src="images/fist.png";
        document.getElementById("roboEscolheu").innerText="O robô escolheu... pedra";
    }
    if(aleatorio == 2){
        document.getElementById("robot-hand").src="images/hand.png";
        document.getElementById("roboEscolheu").innerText="O robô escolheu... papel";
    }
    if(aleatorio == 3){
        document.getElementById("robot-hand").src="images/v.png";
        document.getElementById("roboEscolheu").innerText="O robô escolheu... tesoura";
    }
    else{

    }
}