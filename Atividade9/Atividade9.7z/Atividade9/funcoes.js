function maiorNumero(num1, num2, num3) {
    return Math.max(num1, num2, num3);
}

function ordenarNumeros(num1, num2, num3) {
    let numeros = [num1, num2, num3];
    return numeros.sort((a, b) => a - b);
}

function ehPalindromo(palavra) {
    let palavraUpper = palavra.toUpperCase();
    let reverso = palavraUpper.split('').reverse().join('');
    return palavraUpper === reverso;
}

function saoDiferentes(val1, val2, val3) {
    return (val1 !== val2) && (val1 !== val3) && (val2 !== val3);
}

function testeMaiorNumero() {
    let num1 = parseFloat(document.getElementById("num1").value);
    let num2 = parseFloat(document.getElementById("num2").value);
    let num3 = parseFloat(document.getElementById("num3").value);
    
    let resultado = maiorNumero(num1, num2, num3);
    document.getElementById("resultado1").innerText = "O maior número é: " + resultado;
}

function testeOrdenarNumeros() {
    let num1 = parseFloat(document.getElementById("num1").value);
    let num2 = parseFloat(document.getElementById("num2").value);
    let num3 = parseFloat(document.getElementById("num3").value);
    
    let resultado = ordenarNumeros(num1, num2, num3);
    document.getElementById("resultado2").innerText = "Números em ordem crescente: " + resultado.join(", ");
}

function testePalindromo() {
    let palavra = document.getElementById("palindromo").value;
    
    let resultado = ehPalindromo(palavra);
    document.getElementById("resultado3").innerText = resultado ? "É palíndromo!" : "Não é palíndromo.";
}

function testeSaoDiferentes() {
    let num1 = parseFloat(document.getElementById("num1").value);
    let num2 = parseFloat(document.getElementById("num2").value);
    let num3 = parseFloat(document.getElementById("num3").value);
    
    let resultado = saoDiferentes(num1, num2, num3);
    document.getElementById("resultado4").innerText = resultado ? "Os números são diferentes." : "Os números não são diferentes.";
}
