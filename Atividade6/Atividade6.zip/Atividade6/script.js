//window.alert("Alert;");

document.getElementById("titulo").textContent = "Escolha a página.";